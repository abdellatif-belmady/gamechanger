# main.py

def hello():
    print("This is a gamechanger function!")